#include "IR_handle.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
Basic_block_list basic_head;
void IR_begin_handle(){
    basic_head=NULL;
    Basic_block_list cur_basic=NULL;
    Basic_block_list label_list=NULL;
    Basic_block_list exit=NULL;
    for(InterCodes p=inter_code_head;p!=NULL;p=p->next){
        if(p->code->kind==FUNCTION_IR){
            //deal the basic head
            if(basic_head!=NULL){
                cur_basic->basic_block->tail=p->prev;
                cur_basic->next=exit;
                fill_label(label_list);
                handle_function();
            }
            Basic_block temp=(Basic_block)malloc(sizeof(struct Basic_block_));
            temp->head=p;temp->tail=p;
            temp->in_list=temp->out_list=NULL;
            Basic_block_list temp_list=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            temp_list->basic_block=temp;
            temp_list->next=NULL;
            cur_basic=basic_head=temp_list;
            exit=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            exit->basic_block=(Basic_block)malloc(sizeof(struct Basic_block_));
            exit->next=NULL;
            exit->basic_block->head=exit->basic_block->tail=NULL;
            exit->basic_block->in_list=exit->basic_block->out_list=NULL;
        }
        else if(p->code->kind==LABEL_IR){
            if(p->prev->code->kind!=IFGOTO_IR&&p->prev->code->kind!=GOTO_IR&&p->prev->code->kind!=RETURN_IR){
            Basic_block temp=(Basic_block)malloc(sizeof(struct Basic_block_));
            temp->head=p;temp->tail=p;
            temp->in_list=temp->out_list=NULL;
            Basic_block_list in=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            in->basic_block=cur_basic->basic_block;
            in->next=NULL;temp->in_list=in;
            cur_basic->basic_block->tail=p->prev;
            Basic_block_list out=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            out->basic_block=temp;
            out->next=cur_basic->basic_block->out_list;cur_basic->basic_block->out_list=out;
            Basic_block_list temp_list=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            temp_list->basic_block=temp;
            temp_list->next=NULL;
            cur_basic->next=temp_list;
            cur_basic=temp_list;
            }
            else cur_basic->basic_block->tail=p;
            Basic_block_list label_temp=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            label_temp->basic_block=cur_basic->basic_block;
            label_temp->next=label_list;
            label_list=label_temp;
        }
        else if(p->code->kind==IFGOTO_IR||p->code->kind==GOTO_IR){
            cur_basic->basic_block->tail=p;
            if(p->next!=NULL&&p->next->code->kind!=FUNCTION_IR){
                Basic_block temp=(Basic_block)malloc(sizeof(struct Basic_block_));
                temp->head=p->next;temp->tail=p->next;
                temp->in_list=temp->out_list=NULL;
                if(p->code->kind==IFGOTO_IR){
                    Basic_block_list in=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
                    in->basic_block=cur_basic->basic_block;
                    in->next=NULL;temp->in_list=in;
                    Basic_block_list out=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
                    out->basic_block=temp;
                    out->next=cur_basic->basic_block->out_list;cur_basic->basic_block->out_list=out;
                }
                Basic_block_list temp_list=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
                temp_list->basic_block=temp;
                temp_list->next=NULL;
                cur_basic->next=temp_list;
                cur_basic=temp_list;
            }
            else if(p->code->kind==IFGOTO_IR){
                Basic_block_list out=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
                out->basic_block=exit->basic_block;
                out->next=cur_basic->basic_block->out_list;cur_basic->basic_block->out_list=out;
            }
        }
        else if(p->code->kind==RETURN_IR){
            cur_basic->basic_block->tail=p;
            if(p->next!=NULL&&p->next->code->kind!=FUNCTION_IR){
                Basic_block temp=(Basic_block)malloc(sizeof(struct Basic_block_));
                temp->head=p->next;temp->tail=p->next;
                temp->in_list=temp->out_list=NULL;
                Basic_block_list temp_list=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
                temp_list->basic_block=temp;
                temp_list->next=NULL;
                cur_basic->next=temp_list;
                cur_basic=temp_list;
            }
            Basic_block_list in=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            in->basic_block=cur_basic->basic_block;
            in->next=exit->basic_block->in_list;exit->basic_block->in_list=in;
            Basic_block_list out=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            out->basic_block=exit->basic_block;
            out->next=cur_basic->basic_block->out_list;cur_basic->basic_block->out_list=out;
        }
        else cur_basic->basic_block->tail=p;
    }
    cur_basic->next=exit;
    fill_label(label_list);
    handle_function();
}
/*FILE*f2;
void print_list(ConstantList list){
    for(ConstantList p=list;p!=NULL;p=p->next){
        print_operand(p->var,f2);
        fprintf(f2,":");
        print_operand(p->constant,f2);
        fprintf(f2,",");
    }
    fprintf(f2,"\n");
}*/
void handle_function(){
    //常量传播-公共子表达式消除-常量折叠-控制流优化-无用代码消除-循环不变代码外提-归纳变量强度削减-控制流优化
    /*f2=fopen("/home/xerxes/lab/lab5/Test/cur_out.ir","a+");
    if(!f2){
        exit(1);
    }*/
    Reaching_Definitions();
    constant_folding(0);

    Available_Expression();
    subexpression_elimination();//公共子表达式消除
    
    //print_IR(f2);
    Reaching_Definitions();
    constant_folding(0);//常量折叠

    Live_Variable();
    Dead_Code_Delete();//无用代码消除
    //print_IR(f2);
}

void fill_label(Basic_block_list label_list){
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        Basic_block x=p->basic_block;
        if(x->tail->code->kind==IFGOTO_IR||x->tail->code->kind==GOTO_IR){
            char*name;
            if(x->tail->code->kind==IFGOTO_IR)name=x->tail->code->u.four.op3->op_u.name;
            else name=x->tail->code->u.one.op->op_u.name;
            Basic_block_list search=NULL;
            for(search=label_list;search!=NULL;search=search->next)
                if(strcmp(name,search->basic_block->head->code->u.one.op->op_u.name)==0)break;
            Basic_block_list in=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            in->basic_block=x;
            in->next=search->basic_block->in_list;search->basic_block->in_list=in;
            Basic_block_list out=(Basic_block_list)malloc(sizeof(struct Basic_block_list_));
            out->basic_block=search->basic_block;
            out->next=x->out_list;x->out_list=out;
    }
    }
}

int search_operand_list(OperandList list,Operand op){
    //search successful return 1
    for(OperandList p=list;p!=NULL;p=p->next)
        if(compare_operand(p->op,op,0)==0)return 1;
    return 0;
}

OperandList add_operand_list(OperandList list,Operand x){
    if(x->kind!=VARIABLE_OP)return list;
    OperandList search=NULL;
    for(search=list;search!=NULL;search=search->next)
        if(compare_operand(search->op,x,0)==0)return list;
    OperandList temp=(OperandList)malloc(sizeof(struct OperandList_));
    temp->op=copy_operand(x);
    temp->next=list;
    list=temp;
    return list;
}

OperandList delete_operand_list(OperandList list,Operand x){
    OperandList pre=NULL;OperandList cur=list;
    for(;cur!=NULL;pre=cur,cur=cur->next){
        if(compare_operand(cur->op,x,0)==0){
            if(pre==NULL)list=cur->next;
            else pre->next=cur->next;
            return list;
        }
    }
    return list;
}

void Live_Variable(){//活跃变量
    //fill def_B and use_B
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        p->basic_block->def_B=p->basic_block->use_B=NULL;
        p->basic_block->IN=p->basic_block->OUT=NULL;
        p->next->basic_block->IN=NULL;p->next->basic_block->OUT=NULL;
        for(InterCodes t=p->basic_block->head;t!=p->basic_block->tail->next;t=t->next){
            if(t->code->kind==ASSIGN_IR){
                if(search_operand_list(p->basic_block->def_B,t->code->u.two.op2)==0)
                    p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.two.op2);
                if(t->code->u.two.op1->addr==STAR_OP){
                    if(search_operand_list(p->basic_block->def_B,t->code->u.two.op1)==0)
                        p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.two.op1);
                }
                else if(search_operand_list(p->basic_block->use_B,t->code->u.two.op1)==0)
                    p->basic_block->def_B=add_operand_list(p->basic_block->def_B,t->code->u.two.op1);
            }
            else if(t->code->kind==ADD_IR||t->code->kind==SUB_IR||t->code->kind==MUL_IR||t->code->kind==DIV_IR){
                if(search_operand_list(p->basic_block->def_B,t->code->u.three.op1)==0)
                    p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.three.op1);
                if(search_operand_list(p->basic_block->def_B,t->code->u.three.op2)==0)
                    p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.three.op2);
                if(t->code->u.three.res->addr==STAR_OP){
                    if(search_operand_list(p->basic_block->def_B,t->code->u.three.res)==0)
                        p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.three.res);
                }
                else if(search_operand_list(p->basic_block->use_B,t->code->u.three.res)==0)
                    p->basic_block->def_B=add_operand_list(p->basic_block->def_B,t->code->u.three.res);
            }
            else if(t->code->kind==IFGOTO_IR){
                if(search_operand_list(p->basic_block->def_B,t->code->u.four.op1)==0)
                    p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.four.op1);
                if(search_operand_list(p->basic_block->def_B,t->code->u.four.op2)==0)
                    p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.four.op2);
            }
            else if(t->code->kind==ARG_IR||t->code->kind==READ_IR){
                if(search_operand_list(p->basic_block->use_B,t->code->u.one.op)==0)
                    p->basic_block->def_B=add_operand_list(p->basic_block->def_B,t->code->u.one.op);
            }
            else if(t->code->kind==PARAM_IR||t->code->kind==RETURN_IR||t->code->kind==WRITE_IR){
                if(search_operand_list(p->basic_block->def_B,t->code->u.one.op)==0)
                    p->basic_block->use_B=add_operand_list(p->basic_block->use_B,t->code->u.one.op);
            }
            else if(t->code->kind==CALL_IR){
                if(search_operand_list(p->basic_block->use_B,t->code->u.two.op1)==0)
                    p->basic_block->def_B=add_operand_list(p->basic_block->def_B,t->code->u.two.op1);
            }
        }
    }
    //fill IN and OUT
    int flag=0;
    while(flag==0){
        flag=1;//if IN changed,set flag to 0
        for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
            for(Basic_block_list out=p->basic_block->out_list;out!=NULL;out=out->next){
                for(OperandList out_IN=out->basic_block->IN;out_IN!=NULL;out_IN=out_IN->next){
                    p->basic_block->OUT=add_operand_list(p->basic_block->OUT,out_IN->op);
                }
            }
            for(OperandList use=p->basic_block->use_B;use!=NULL;use=use->next){
                if(search_operand_list(p->basic_block->IN,use->op)==0){
                    flag=0;
                    OperandList temp=(OperandList)malloc(sizeof(struct OperandList_));
                    temp->op=copy_operand(use->op);
                    temp->next=p->basic_block->IN;
                    p->basic_block->IN=temp;
                }
            }
            for(OperandList out=p->basic_block->OUT;out!=NULL;out=out->next){
                if(search_operand_list(p->basic_block->def_B,out->op)==0&&
                    search_operand_list(p->basic_block->IN,out->op)==0){
                    flag=0;
                    OperandList temp=(OperandList)malloc(sizeof(struct OperandList_));
                    temp->op=copy_operand(out->op);
                    temp->next=p->basic_block->IN;
                    p->basic_block->IN=temp;
                }
            }
        }
    }
}

void Dead_Code_Delete(){
    int flag=0;
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        OperandList active_list=p->basic_block->OUT;
        for(InterCodes t=p->basic_block->tail;t!=p->basic_block->head->prev;t=t->prev){
            //fprintf(f2,"line%d:",t->num);
            //print_active_list(active_list);
            if(t->code->kind==ASSIGN_IR&&t->code->u.two.op1->addr!=STAR_OP){
                if(search_operand_list(active_list,t->code->u.two.op1)==0){
                    //delete t
                    //fprintf(f2,"delete line%d,",t->num);
                    if(p->basic_block->head==t)p->basic_block->head=t->next;
                    if(p->basic_block->tail==t)p->basic_block->tail=t->prev;
                    if(t->prev!=NULL)t->prev->next=t->next;
                    if(t->next!=NULL)t->next->prev=t->prev;
                    t=t->next;
                    //fprintf(f2,"changed to line%d\n",t->num);
                }
                else{
                    //op1 is not active, op2 is active
                    active_list=delete_operand_list(active_list,t->code->u.two.op1);
                    active_list=add_operand_list(active_list,t->code->u.two.op2);
                }
            }
            else if(t->code->kind==ASSIGN_IR&&t->code->u.two.op1->addr==STAR_OP){
                //op1 and op2 are both active
                active_list=add_operand_list(active_list,t->code->u.two.op1);
                active_list=add_operand_list(active_list,t->code->u.two.op2);
            }
            else if(t->code->kind==ADD_IR||t->code->kind==SUB_IR||t->code->kind==MUL_IR||t->code->kind==DIV_IR){
                if(t->code->u.three.res->addr==STAR_OP){
                    active_list=add_operand_list(active_list,t->code->u.three.op1);
                    active_list=add_operand_list(active_list,t->code->u.three.op2);
                    active_list=add_operand_list(active_list,t->code->u.three.res);
                }
                else{
                    if(search_operand_list(active_list,t->code->u.three.res)==0){
                        //delete t
                        if(p->basic_block->head==t)p->basic_block->head=t->next;
                        if(p->basic_block->tail==t)p->basic_block->tail=t->prev;
                        if(t->prev!=NULL)t->prev->next=t->next;
                        if(t->next!=NULL)t->next->prev=t->prev;
                        t=t->next;
                    }
                    else{
                        //res is not active, op1 and op2 is active
                        active_list=delete_operand_list(active_list,t->code->u.three.res);
                        active_list=add_operand_list(active_list,t->code->u.three.op1);
                        active_list=add_operand_list(active_list,t->code->u.three.op2);
                    }
                }
            }
            else if(t->code->kind==IFGOTO_IR){
                active_list=add_operand_list(active_list,t->code->u.four.op1);
                active_list=add_operand_list(active_list,t->code->u.four.op2);
            }
            else if(t->code->kind==ARG_IR||t->code->kind==READ_IR){
                active_list=delete_operand_list(active_list,t->code->u.one.op);
            }
            else if(t->code->kind==PARAM_IR||t->code->kind==RETURN_IR||t->code->kind==WRITE_IR){
                active_list=add_operand_list(active_list,t->code->u.one.op);
            }
            else if(t->code->kind==CALL_IR){
                active_list=delete_operand_list(active_list,t->code->u.two.op1);
            }
        }
        for(OperandList t=p->basic_block->IN;t!=NULL;t=t->next)
            if(search_operand_list(active_list,t->op)==0){
                flag=1;break;
            }
    }
    if(flag==1){
        //print_IR(f2);
        Live_Variable();
        Dead_Code_Delete();
    }
}

InterCodes Insert_InterCodes(InterCodes list,InterCodes t){
    InterCodes x=copy_intercodes(t);
    for(InterCodes p=list;p!=NULL;p=p->next){
        if(compare_operand(p->code->u.three.res,x->code->u.three.res,1)==0&&
            compare_operand(p->code->u.three.op1,x->code->u.three.op1,1)==0&&
            compare_operand(p->code->u.three.op2,x->code->u.three.op2,1)==0&&
            p->code->kind==x->code->kind){
            return list;
        }
    }
    x->next=list;
    if(list!=NULL)list->prev=x;
    list=x;
    return list;
}

int search_intercodes(InterCodes list,InterCodes x){
    //succ return 1;
    for(InterCodes p=list;p!=NULL;p=p->next){
        if(compare_operand(p->code->u.three.res,x->code->u.three.res,1)==0&&
            compare_operand(p->code->u.three.op1,x->code->u.three.op1,1)==0&&
            compare_operand(p->code->u.three.op2,x->code->u.three.op2,1)==0&&
            p->code->kind==x->code->kind){
            return 1;
        }
    }
    return 0;
}

void Available_Expression(){//可用表达式
    //fill e_gen,e_kill
    InterCodes all_exps=NULL;
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        p->basic_block->e_gen=NULL;p->basic_block->e_kill=NULL;
        p->basic_block->e_IN=p->basic_block->e_OUT=NULL;
        for(InterCodes t=p->basic_block->head;t!=p->basic_block->tail->next;t=t->next){
            if(t->code->kind==ADD_IR||t->code->kind==SUB_IR||t->code->kind==MUL_IR||t->code->kind==DIV_IR){
                InterCodes search=NULL;
                Operand cur_res=t->code->u.three.res;
                InterCodes temp=copy_intercodes(t);
                //remove all exp about res from e_gen
                for(InterCodes to_delete=p->basic_block->e_gen;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else p->basic_block->e_gen=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
                //add res into e_kill
                p->basic_block->e_kill=add_operand_list(p->basic_block->e_kill,cur_res);
                //add t's exp into e_gen
                if(compare_operand(cur_res,temp->code->u.three.op1,0)!=0&&
                    compare_operand(cur_res,temp->code->u.three.op2,0)!=0){
                    temp->next=p->basic_block->e_gen;
                    if(p->basic_block->e_gen!=NULL)p->basic_block->e_gen->prev=temp;
                    temp->prev=NULL;
                    p->basic_block->e_gen=temp;
                }
                all_exps=Insert_InterCodes(all_exps,t);
            }
            else if(t->code->kind==ASSIGN_IR){
                Operand cur_res=t->code->u.two.op1;
                //remove all exp about res from e_gen
                for(InterCodes to_delete=p->basic_block->e_gen;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else p->basic_block->e_gen=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
                //add res into e_kill
                p->basic_block->e_kill=add_operand_list(p->basic_block->e_kill,cur_res);
            }
            else if(t->code->kind==READ_IR){
                Operand cur_res=t->code->u.one.op;
                //remove all exp about res from e_gen
                for(InterCodes to_delete=p->basic_block->e_gen;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else p->basic_block->e_gen=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
                //add res into e_kill
                p->basic_block->e_kill=add_operand_list(p->basic_block->e_kill,cur_res);
            }
            else if(t->code->kind==CALL_IR){
                Operand cur_res=t->code->u.two.op1;
                //remove all exp about res from e_gen
                for(InterCodes to_delete=p->basic_block->e_gen;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else p->basic_block->e_gen=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
                //add res into e_kill
                p->basic_block->e_kill=add_operand_list(p->basic_block->e_kill,cur_res);
            }
        }
    }
    //fill e_IN and e_OUT
    int flag=0;
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        p->basic_block->e_OUT=all_exps;
    }
    basic_head->basic_block->e_IN=NULL;
    basic_head->basic_block->e_OUT=basic_head->basic_block->e_gen;
    while(flag==0){
        flag=1;//if IN changed,set flag to 0
        for(Basic_block_list p=basic_head->next;p->basic_block->head!=NULL;p=p->next){
            p->basic_block->e_IN=NULL;
            for(InterCodes out=p->basic_block->in_list->basic_block->e_OUT;out!=NULL;out=out->next){
                InterCodes temp=copy_intercodes(out);
                temp->next=p->basic_block->e_IN;
                if(p->basic_block->e_IN!=NULL)p->basic_block->e_IN->prev=temp;
                p->basic_block->e_IN=temp;
            }
            for(Basic_block_list in=p->basic_block->in_list->next;in!=NULL;in=in->next){
                for(InterCodes to_delete=p->basic_block->e_IN;to_delete!=NULL;to_delete=to_delete->next){
                    if(search_intercodes(in->basic_block->e_OUT,to_delete)==0){
                        if(to_delete->prev==NULL)p->basic_block->e_IN=to_delete->next;
                        else to_delete->prev->next=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
            }
            InterCodes new_out=NULL;
            for(InterCodes in=p->basic_block->e_IN;in!=NULL;in=in->next){
                OperandList search=p->basic_block->e_kill;
                for(;search!=NULL;search=search->next)
                    if(compare_operand(search->op,in->code->u.three.res,0)==0||
                        compare_operand(search->op,in->code->u.three.op1,0)==0||
                        compare_operand(search->op,in->code->u.three.op2,0)==0)
                        break;
                if(search==NULL)
                    new_out=Insert_InterCodes(new_out,in);
            }
            for(InterCodes gen=p->basic_block->e_gen;gen!=NULL;gen=gen->next)
                new_out=Insert_InterCodes(new_out,gen);
            for(InterCodes old_out=p->basic_block->e_OUT;old_out!=NULL;old_out=old_out->next)
                if(search_intercodes(new_out,old_out)==0)
                    flag=0;
            p->basic_block->e_OUT=new_out;
        }
    }
}

void subexpression_elimination(){//公共子表达式消除
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        InterCodes available_list=p->basic_block->e_IN;
        for(InterCodes t=p->basic_block->head;t!=p->basic_block->tail->next;t=t->next){
            if(t->code->kind==ADD_IR||t->code->kind==SUB_IR||t->code->kind==MUL_IR||t->code->kind==DIV_IR){
                InterCodes search=NULL;
                Operand cur_res=t->code->u.three.res;
                InterCodes temp=copy_intercodes(t);
                for(search=available_list;search!=NULL;search=search->next){
                    if(compare_operand(t->code->u.three.op1,search->code->u.three.op1,1)==0&&
                        compare_operand(t->code->u.three.op2,search->code->u.three.op2,1)==0&&
                        t->code->kind==search->code->kind){
                        InterCode new_t=(InterCode)malloc(sizeof(struct InterCode_));
                        new_t->kind=ASSIGN_IR;
                        new_t->u.two.op1=cur_res;
                        new_t->u.two.op2=copy_operand(search->code->u.three.res);
                        t->code=new_t;
                        break;
                    }
                }
                for(InterCodes to_delete=available_list;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else available_list=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
                if(compare_operand(cur_res,temp->code->u.three.op1,0)!=0&&
                    compare_operand(cur_res,temp->code->u.three.op2,0)!=0){
                    temp->next=available_list;
                    if(available_list!=NULL)available_list->prev=temp;
                    temp->prev=NULL;
                    available_list=temp;
                }
            }
            else if(t->code->kind==ASSIGN_IR){
                Operand cur_res=t->code->u.two.op1;
                for(InterCodes to_delete=available_list;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else available_list=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
            }
            else if(t->code->kind==READ_IR){
                Operand cur_res=t->code->u.one.op;
                for(InterCodes to_delete=available_list;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else available_list=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
            }
            else if(t->code->kind==CALL_IR){
                Operand cur_res=t->code->u.two.op1;
                for(InterCodes to_delete=available_list;to_delete!=NULL;to_delete=to_delete->next){
                    if(compare_operand(cur_res,to_delete->code->u.three.res,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op1,0)==0||
                        compare_operand(cur_res,to_delete->code->u.three.op2,0)==0){
                        if(to_delete->prev!=NULL)to_delete->prev->next=to_delete->next;
                        else available_list=to_delete->next;
                        if(to_delete->next!=NULL)to_delete->next->prev=to_delete->prev;
                    }
                }
            }
        }
    }
}

Operand search_constant(ConstantList list,Operand v){
    for(ConstantList p=list;p!=NULL;p=p->next)
        if(compare_operand(p->var,v,1)==0)return copy_operand(p->constant);
    return NULL;
}

ConstantList add_constant(ConstantList list,Operand v,Operand c){
    for(ConstantList p=list;p!=NULL;p=p->next)
        if(compare_operand(p->var,v,1)==0){
            p->constant=copy_operand(c);
            return list;
        }
    ConstantList t=(ConstantList)malloc(sizeof(struct ConstantList_));
    t->constant=copy_operand(c);
    t->var=copy_operand(v);
    t->next=list;
    list=t;
    return list;
}

ConstantList delete_constant(ConstantList list,Operand v){
    ConstantList pre=NULL;
    for(ConstantList p=list;p!=NULL;pre=p,p=p->next){
        if(compare_operand(p->var,v,1)==0){
            if(pre==NULL)list=p->next;
            else pre->next=p->next;
            return list;
        }
    }
    return list;
}

void Reaching_Definitions(){//到达定值
    //fill def_B and use_B
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        p->basic_block->r_gen=NULL;p->basic_block->r_kill=NULL;
        p->basic_block->r_IN=p->basic_block->r_OUT=NULL;
        for(InterCodes t=p->basic_block->head;t!=p->basic_block->tail->next;t=t->next){
            if(t->code->kind==ASSIGN_IR&&t->code->u.two.op1->addr!=STAR_OP){
                p->basic_block->r_gen=add_constant(p->basic_block->r_gen,t->code->u.two.op1,t->code->u.two.op2);
                p->basic_block->r_kill=add_operand_list(p->basic_block->r_kill,t->code->u.two.op1);
            }
            else if(t->code->kind==ADD_IR||t->code->kind==SUB_IR||t->code->kind==MUL_IR||t->code->kind==DIV_IR){
                Operand temp=(Operand)malloc(sizeof(struct Operand_));
                temp->kind=VARIABLE_OP;
                temp->op_u.var_no=-1;
                p->basic_block->r_gen=add_constant(p->basic_block->r_gen,t->code->u.three.res,temp);
                p->basic_block->r_kill=add_operand_list(p->basic_block->r_kill,t->code->u.three.res);
            }
            else if(t->code->kind==READ_IR){
                Operand temp=(Operand)malloc(sizeof(struct Operand_));
                temp->kind=VARIABLE_OP;
                temp->op_u.var_no=-1;
                p->basic_block->r_gen=add_constant(p->basic_block->r_gen,t->code->u.one.op,temp);
                p->basic_block->r_kill=add_operand_list(p->basic_block->r_kill,t->code->u.one.op);
            }
            else if(t->code->kind==CALL_IR){
                Operand temp=(Operand)malloc(sizeof(struct Operand_));
                temp->kind=VARIABLE_OP;
                temp->op_u.var_no=-1;
                p->basic_block->r_gen=add_constant(p->basic_block->r_gen,t->code->u.two.op1,temp);
                p->basic_block->r_kill=add_operand_list(p->basic_block->r_kill,t->code->u.two.op1);
            }
        }
    }
    //fill IN and OUT
    int flag=0;
    while(flag==0){
        flag=1;//if IN changed,set flag to 0
        for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
            p->basic_block->r_IN=NULL;
            OperandList to_delete=NULL;
            for(Basic_block_list in=p->basic_block->in_list;in!=NULL;in=in->next){
                for(ConstantList in_OUT=in->basic_block->r_OUT;in_OUT!=NULL;in_OUT=in_OUT->next){
                    if(in_OUT->constant->kind==CONSTANT_OP){
                        Operand search=search_constant(p->basic_block->r_IN,in_OUT->var);
                        if(search==NULL||search->op_u.value==in_OUT->constant->op_u.value)
                            p->basic_block->r_IN=add_constant(p->basic_block->r_IN,in_OUT->var,in_OUT->constant);
                        else{
                            OperandList temp=(OperandList)malloc(sizeof(struct OperandList_));
                            temp->op=copy_operand(in_OUT->var);
                            temp->next=to_delete;
                            to_delete=temp;
                        }
                    }
                }
            }
            for(;to_delete!=NULL;to_delete=to_delete->next){
                p->basic_block->r_IN=delete_constant(p->basic_block->r_IN,to_delete->op);
                Operand temp=(Operand)malloc(sizeof(struct Operand_));
                temp->kind=VARIABLE_OP;
                temp->op_u.var_no=-1;
                p->basic_block->r_IN=add_constant(p->basic_block->r_IN,to_delete->op,temp);
            }
            for(Basic_block_list in=p->basic_block->in_list;in!=NULL;in=in->next){
                for(ConstantList in_OUT=in->basic_block->r_OUT;in_OUT!=NULL;in_OUT=in_OUT->next){
                    if(in_OUT->constant->kind!=CONSTANT_OP){
                        p->basic_block->r_IN=delete_constant(p->basic_block->r_IN,in_OUT->var);
                        Operand temp=(Operand)malloc(sizeof(struct Operand_));
                        temp->kind=VARIABLE_OP;
                        temp->op_u.var_no=-1;
                        p->basic_block->r_IN=add_constant(p->basic_block->r_IN,in_OUT->var,temp);
                    }
                }
            }

            ConstantList new_out=NULL;
            for(ConstantList in=p->basic_block->r_IN;in!=NULL;in=in->next){
                if(search_operand_list(p->basic_block->r_kill,in->var)==0){
                    new_out=add_constant(new_out,in->var,in->constant);
                }
            }
            for(ConstantList use=p->basic_block->r_gen;use!=NULL;use=use->next){
                new_out=add_constant(new_out,use->var,use->constant);
            }
            for(ConstantList old_out=p->basic_block->r_OUT;old_out!=NULL;old_out=old_out->next)
                if(search_constant(new_out,old_out->var)==NULL){flag=0;break;}
            for(ConstantList tmp=new_out;tmp!=NULL;tmp=tmp->next)
                if(search_constant(p->basic_block->r_OUT,tmp->var)==NULL){flag=0;break;}
            p->basic_block->r_OUT=new_out;
        }
    }


    /*for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
            fprintf(f2,"out:\n");
            for(Basic_block_list in=p->basic_block->in_list;in!=NULL;in=in->next){
                fprintf(f2,"line%d:",in->basic_block->head->num);
                print_list(in->basic_block->r_OUT);
            }
            fprintf(f2,"in:\n");
            print_list(p->basic_block->r_IN);
    }*/
}

void constant_folding(int m){
    for(Basic_block_list p=basic_head;p->basic_block->head!=NULL;p=p->next){
        ConstantList constant_list=NULL;
        if(m==0)constant_list=p->basic_block->r_IN;
        else constant_list=NULL;
        for(ConstantList t=constant_list;t!=NULL;t=t->next){
            if(t->constant->kind!=CONSTANT_OP)
                constant_list=delete_constant(constant_list,t->var);
        }
        //fprintf(f2,"line%d:",p->basic_block->head->num);
        //print_list(constant_list);
        for(InterCodes t=p->basic_block->head;t!=p->basic_block->tail->next;t=t->next){
            //fprintf(f2,"line%d:",t->num);
            //print_list(constant_list);
            if(t->code->kind==ASSIGN_IR&&t->code->u.two.op1->addr!=STAR_OP){
                if(t->code->u.two.op2->kind==CONSTANT_OP)
                    constant_list=add_constant(constant_list,t->code->u.two.op1,t->code->u.two.op2);
                else{
                    Operand search=search_constant(constant_list,t->code->u.two.op2);
                    if(search==NULL)
                        constant_list=delete_constant(constant_list,t->code->u.two.op1);
                    else{
                        t->code->u.two.op2=search;
                        constant_list=add_constant(constant_list,t->code->u.two.op1,search);
                    }
                }
            }
            else if(t->code->kind==ADD_IR||t->code->kind==SUB_IR||t->code->kind==MUL_IR||t->code->kind==DIV_IR){
                Operand s1=NULL;Operand s2=NULL;
                if(t->code->u.three.op1->kind==CONSTANT_OP)s1=t->code->u.three.op1;
                else s1=search_constant(constant_list,t->code->u.three.op1);
                if(t->code->u.three.op2->kind==CONSTANT_OP)s2=t->code->u.three.op2;
                else s2=search_constant(constant_list,t->code->u.three.op2);
                if(s1!=NULL&&s2!=NULL){
                    if(t->code->kind==ADD_IR)
                        s1->op_u.value=s1->op_u.value+s2->op_u.value;
                    else if(t->code->kind==SUB_IR)
                        s1->op_u.value=s1->op_u.value-s2->op_u.value;
                    else if(t->code->kind==MUL_IR)
                        s1->op_u.value=s1->op_u.value*s2->op_u.value;
                    else
                        s1->op_u.value=s1->op_u.value/s2->op_u.value;
                    t->code->kind=ASSIGN_IR;
                    t->code->u.two.op1=t->code->u.three.res;
                    t->code->u.two.op2=s1;
                    constant_list=add_constant(constant_list,t->code->u.two.op1,s1);
                }
                else if(s1!=NULL){
                    t->code->u.three.op1=s1;
                    constant_list=delete_constant(constant_list,t->code->u.three.res);
                }
                else if(s2!=NULL){
                    t->code->u.three.op2=s2;
                    constant_list=delete_constant(constant_list,t->code->u.three.res);
                }
                else constant_list=delete_constant(constant_list,t->code->u.three.res);
            }
            else if(t->code->kind==IFGOTO_IR){
                if(t->code->u.four.op1->kind!=CONSTANT_OP){
                    Operand search=search_constant(constant_list,t->code->u.four.op1);
                    if(search!=NULL)t->code->u.four.op1=search;
                }
                if(t->code->u.four.op2->kind!=CONSTANT_OP){
                    Operand search=search_constant(constant_list,t->code->u.four.op2);
                    if(search!=NULL)t->code->u.four.op2=search;
                }
            }
            else if(t->code->kind==READ_IR){
                constant_list=delete_constant(constant_list,t->code->u.one.op);
            }
            else if(t->code->kind==PARAM_IR||t->code->kind==RETURN_IR||t->code->kind==WRITE_IR){
                Operand search=search_constant(constant_list,t->code->u.one.op);
                if(search!=NULL)
                    t->code->u.one.op=search;
            }
            else if(t->code->kind==CALL_IR){
                constant_list=delete_constant(constant_list,t->code->u.two.op1);
            }
        }
    }
}

//./parser /home/xerxes/lab/lab5/Test/test.ir /home/xerxes/lab/lab5/Test/out.ir