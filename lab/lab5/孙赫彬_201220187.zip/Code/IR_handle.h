#ifndef DEF_HANDLE
#define DEF_HANDLE
#include "IR_structure.h"

typedef struct Basic_block_* Basic_block;
typedef struct Basic_block_list_* Basic_block_list;
typedef struct ConstantList_* ConstantList;
struct Basic_block_{
    InterCodes head;
    InterCodes tail;
    OperandList def_B,use_B;//活跃变量
    OperandList IN,OUT;//活跃变量
    InterCodes e_gen;OperandList e_kill;//可用表达式
    InterCodes e_IN,e_OUT;//可用表达式
    ConstantList r_gen,r_IN,r_OUT;OperandList r_kill;//到达定值
    Basic_block_list in_list;
    Basic_block_list out_list;
};

struct Basic_block_list_{
    Basic_block basic_block;
    Basic_block_list next;
};
struct ConstantList_{
    Operand var;
    Operand constant;
    ConstantList next;
};

void IR_begin_handle();
void handle_function();
void fill_label(Basic_block_list label_list);
void Live_Variable();//活跃变量
void Dead_Code_Delete();//无用代码消除
void Available_Expression();//可用表达式
void subexpression_elimination();//公共子表达式消除
void Reaching_Definitions();//到达定值
void constant_folding(int m);//常量折叠
#endif