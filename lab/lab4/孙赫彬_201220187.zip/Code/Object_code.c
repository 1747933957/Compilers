#include "Object_code.h"
int cur_line;
FILE*obj_fp;
void object_code_translate(FILE*fp){
	obj_list=NULL;cur_offset=4;cur_line=0;
	obj_fp=fp;
    fprintf(obj_fp,".data\n");
    fprintf(obj_fp,"_prompt: .asciiz \"Enter an integer:\"\n");
    fprintf(obj_fp,"_ret: .asciiz \"\\n\"\n");
    fprintf(obj_fp,".globl main\n");
    fprintf(obj_fp,".text\n");
    fprintf(obj_fp,"read:\n");
    fprintf(obj_fp,"\tli $v0, 4\n");
	fprintf(obj_fp,"\tla $a0, _prompt\n");
	fprintf(obj_fp,"\tsyscall\n");
	fprintf(obj_fp,"\tli $v0, 5\n");
	fprintf(obj_fp,"\tsyscall\n");
	fprintf(obj_fp,"\tjr $ra\n\n");
    fprintf(obj_fp,"write:\n");
    fprintf(obj_fp,"\tli $v0, 1\n");
    fprintf(obj_fp,"\tsyscall\n");
    fprintf(obj_fp,"\tli $v0, 4\n");
    fprintf(obj_fp,"\tla $a0, _ret\n");
    fprintf(obj_fp,"\tsyscall\n");
    fprintf(obj_fp,"\tmove $v0, $0\n");
    fprintf(obj_fp,"\tjr $ra\n\n");
    for(int i=0;i<32;++i)my_regs[i].free=0,my_regs[i].content=NULL;
    my_regs[0].name="$zero";
	my_regs[1].name="$at";
	my_regs[2].name="$v0";
	my_regs[3].name="$v1";
	my_regs[4].name="$a0";
	my_regs[5].name="$a1";
	my_regs[6].name="$a2";
	my_regs[7].name="$a3";
	my_regs[8].name="$t0";
	my_regs[9].name="$t1";
	my_regs[10].name="$t2";
	my_regs[11].name="$t3";
	my_regs[12].name="$t4";
	my_regs[13].name="$t5";
	my_regs[14].name="$t6";
	my_regs[15].name="$t7";
	my_regs[16].name="$s0";
	my_regs[17].name="$s1";
	my_regs[18].name="$s2";
	my_regs[19].name="$s3";
	my_regs[20].name="$s4";
	my_regs[21].name="$s5";
	my_regs[22].name="$s6";
	my_regs[23].name="$s7";
	my_regs[24].name="$t8";
	my_regs[25].name="$t9";
	my_regs[26].name="$k0";
	my_regs[27].name="$k1";
	my_regs[28].name="$gp";
	my_regs[29].name="$sp";
	my_regs[30].name="$fp";
	my_regs[31].name="$ra";

	for(InterCodes p=inter_code_head;p!=NULL;p=p->next){
		if(p->code->kind==LABEL_IR)obj_label(p);
		else if(p->code->kind==FUNCTION_IR)obj_function(p);
		else if(p->code->kind==ASSIGN_IR)obj_assign(p);
		else if(p->code->kind==ADD_IR)obj_add(p);
		else if(p->code->kind==SUB_IR)obj_sub(p);
		else if(p->code->kind==MUL_IR)obj_mul(p);
		else if(p->code->kind==DIV_IR)obj_div(p);
		else if(p->code->kind==GETADDR_IR)obj_getaddr(p);
		else if(p->code->kind==GETVALUE_IR)obj_getvalue(p);
		else if(p->code->kind==PUTADDR_IR)obj_putaddr(p);
		else if(p->code->kind==GOTO_IR)obj_goto(p);
		else if(p->code->kind==IFGOTO_IR)obj_ifgoto(p);
		else if(p->code->kind==RETURN_IR)obj_return(p);
		else if(p->code->kind==DEC_IR)obj_dec(p);
		else if(p->code->kind==ARG_IR)p=obj_arg(p);
		else if(p->code->kind==CALL_IR)obj_call(p);
		else if(p->code->kind==READ_IR)obj_read(p);
		else if(p->code->kind==WRITE_IR)obj_write(p);
		++cur_line;
	}
}

void delete_objlist(OBJ_symList x){
	OBJ_symList p,pre;
	for(p=obj_list;p!=NULL;pre=p,p=p->next){
		if(p==x&&p!=obj_list){
			pre->next=p->next;
			break;
		}
		else if(p==x&&p==obj_list){
			obj_list=p->next;
		}
	}
}
void clear_regs(){
	for(int i=8;i<=25;++i){
		my_regs[i].free=0;
		my_regs[i].can_free=0;
		my_regs[i].content=NULL;
	}
}
void save_regs(){
	for(int i=8;i<=25;++i){
		if(my_regs[i].free!=0){
			if(my_regs[i].can_free==1){
			//if(my_regs[i].content->op->kind==CONSTANT_OP||my_regs[i].content->op->kind==TEMP_OP){
				delete_objlist(my_regs[i].content);
				my_regs[i].content=NULL;
				my_regs[i].free=0;
				my_regs[i].can_free=0;
			}
			else{
			if(my_regs[i].content->offset>0){//not in stack,get a place in stack
				my_regs[i].content->offset=-cur_offset;
				fprintf(obj_fp,"\taddi $sp, $fp, -%d\n",cur_offset);
				cur_offset=cur_offset+4;
			}//store data into stack
			fprintf(obj_fp,"\tsw %s, %d($fp)\n",my_regs[i].name,my_regs[i].content->offset);
			my_regs[i].content->reg=-1;
			my_regs[i].content=NULL;
			my_regs[i].free=0;
			my_regs[i].can_free=0;
			}
		}
	}
}
int getReg(Operand op){
	int flag=0;
	OBJ_symList p;
	for(p=obj_list;p!=NULL;p=p->next){
		if(compare_operand(p->op,op)==0){
			if(p->reg!=-1){
				if((op->kind==CONSTANT_OP||op->kind==TEMP_OP)&&op->last_used==1)
					my_regs[p->reg].can_free=1;
				my_regs[p->reg].pre_used_line=cur_line;
				return p->reg;
			}
			else{flag=1;break;}
		}
	}
	//get a reg for p
	int i;int oldest=8;
	for(i=8;i<=25;++i){
		if(my_regs[i].free==0)break;
		else if(my_regs[i].can_free==1){
			delete_objlist(my_regs[i].content);
			break;
		}
		else if(my_regs[i].pre_used_line<my_regs[oldest].pre_used_line)oldest=i;
	}
	if(i>25){//no free reg,get the reg used farest(oldest)
		if(my_regs[oldest].content->offset>0){//not in stack,get a place in stack
			my_regs[oldest].content->offset=-cur_offset;
			fprintf(obj_fp,"\taddi $sp, $fp, -%d\n",cur_offset);
			cur_offset=cur_offset+4;
		}//store data into stack
		fprintf(obj_fp,"\tsw %s, %d($fp)\n",my_regs[oldest].name,my_regs[oldest].content->offset);
		my_regs[oldest].content->reg=-1;
		i=oldest;
	}
	if(flag==0){
		//new a OBJ_symList
		p=(OBJ_symList)malloc(sizeof(struct OBJ_symList_));
		p->next=obj_list;
		p->reg=i;
		if(op->kind==VARIABLE_OP){
			p->offset=-cur_offset;
			fprintf(obj_fp,"\taddi $sp, $fp, -%d\n",cur_offset);
			cur_offset=cur_offset+4;
		}
		else p->offset=1024;
		p->op=op;
		obj_list=p;
	}
	//i is the reg for p
	p->reg=i;
	my_regs[i].free=1;
	my_regs[i].pre_used_line=cur_line;
	my_regs[i].content=p;
	my_regs[i].can_free=0;
	if((op->kind==CONSTANT_OP||op->kind==TEMP_OP)&&op->last_used==1)my_regs[i].can_free=1;
	if(op->kind==CONSTANT_OP)
		fprintf(obj_fp,"\tli %s, %d\n",my_regs[i].name,op->op_u.value);
	else if(p->offset<0)
		fprintf(obj_fp,"\tlw %s, %d($fp)\n",my_regs[i].name,p->offset);
	return i;
}
void obj_label(InterCodes p){
	save_regs();
	fprintf(obj_fp,"label%d:\n",p->code->u.one.op->op_u.var_no);
}
void obj_assign(InterCodes p){
	Operand op1=p->code->u.two.op1;
	Operand op2=p->code->u.two.op2;
	if(op2->kind==CONSTANT_OP){
		int op1_num=getReg(p->code->u.two.op1);
		fprintf(obj_fp,"\tli %s, %d\n",my_regs[op1_num].name,op2->op_u.value);
	}
	else{
		int op1_num=getReg(p->code->u.two.op1);
		int op2_num=getReg(p->code->u.two.op2);
		fprintf(obj_fp,"\tmove %s, %s\n",my_regs[op1_num].name,my_regs[op2_num].name);
	}
}
void obj_add(InterCodes p){
	int res_num=getReg(p->code->u.three.res);
	int op1_num=getReg(p->code->u.three.op1);
	int op2_num=getReg(p->code->u.three.op2);
	fprintf(obj_fp,"\tadd %s, %s, %s\n",my_regs[res_num].name,my_regs[op1_num].name,my_regs[op2_num].name);
}
void obj_sub(InterCodes p){
	int res_num=getReg(p->code->u.three.res);
	int op1_num=getReg(p->code->u.three.op1);
	int op2_num=getReg(p->code->u.three.op2);
	fprintf(obj_fp,"\tsub %s, %s, %s\n",my_regs[res_num].name,my_regs[op1_num].name,my_regs[op2_num].name);
}
void obj_mul(InterCodes p){
	int res_num=getReg(p->code->u.three.res);
	int op1_num=getReg(p->code->u.three.op1);
	int op2_num=getReg(p->code->u.three.op2);
	fprintf(obj_fp,"\tmul %s, %s, %s\n",my_regs[res_num].name,my_regs[op1_num].name,my_regs[op2_num].name);
}
void obj_div(InterCodes p){
	int res_num=getReg(p->code->u.three.res);
	int op1_num=getReg(p->code->u.three.op1);
	int op2_num=getReg(p->code->u.three.op2);
	fprintf(obj_fp,"\tdiv %s, %s\n\tmflo %s\n",my_regs[op1_num].name,my_regs[op2_num].name,my_regs[res_num].name);
}
void obj_getvalue(InterCodes p){
	int op1_num=getReg(p->code->u.two.op1);
	int op2_num=getReg(p->code->u.two.op2);
	fprintf(obj_fp,"\tlw %s, 0(%s)\n",my_regs[op1_num].name,my_regs[op2_num].name);
}
void obj_putaddr(InterCodes p){
	int op1_num=getReg(p->code->u.two.op1);
	int op2_num=getReg(p->code->u.two.op2);
	fprintf(obj_fp,"\tsw %s, 0(%s)\n",my_regs[op2_num].name,my_regs[op1_num].name);
}
void obj_print_function(Operand op){
	if(strcmp(op->op_u.name,"main")==0)
		fprintf(obj_fp,"%s",op->op_u.name);
	else
		fprintf(obj_fp,"my_%s",op->op_u.name);
}
void obj_goto(InterCodes p){
	save_regs();
	Operand op=p->code->u.one.op;
	if(op->kind==FUNCTION_OP){
		fprintf(obj_fp,"\tj ");
		obj_print_function(op);
		fprintf(obj_fp,"\n");
	}
	else if(op->kind==LABEL_OP)
		fprintf(obj_fp,"\tj label%d\n",op->op_u.var_no);
}
void obj_ifgoto(InterCodes p){
	save_regs();
	Operand x=p->code->u.four.op1;
	int x_num=getReg(x);
	Operand y=p->code->u.four.op2;
	int y_num=getReg(y);
	Operand z=p->code->u.four.op3;
	char*relop=p->code->u.four.relop;
	if(strcmp(relop,"==")==0){
		if(z->kind==FUNCTION_OP){
			fprintf(obj_fp,"\tbeq %s, %s, ",my_regs[x_num].name,my_regs[y_num].name);
			obj_print_function(z);
			fprintf(obj_fp,"\n");
		}
		else if(z->kind==LABEL_OP)
			fprintf(obj_fp,"\tbeq %s, %s, label%d\n",my_regs[x_num].name,my_regs[y_num].name,z->op_u.var_no);
	}
	else if(strcmp(relop,"!=")==0){
		if(z->kind==FUNCTION_OP){
			fprintf(obj_fp,"\tbne %s, %s, ",my_regs[x_num].name,my_regs[y_num].name);
			obj_print_function(z);
			fprintf(obj_fp,"\n");
		}
			else if(z->kind==LABEL_OP)
			fprintf(obj_fp,"\tbne %s, %s, label%d\n",my_regs[x_num].name,my_regs[y_num].name,z->op_u.var_no);
	}
	else if(strcmp(relop,">")==0){
		if(z->kind==FUNCTION_OP){
			fprintf(obj_fp,"\tbgt %s, %s, ",my_regs[x_num].name,my_regs[y_num].name);
			obj_print_function(z);
			fprintf(obj_fp,"\n");
		}
		else if(z->kind==LABEL_OP)
			fprintf(obj_fp,"\tbgt %s, %s, label%d\n",my_regs[x_num].name,my_regs[y_num].name,z->op_u.var_no);
	}
	else if(strcmp(relop,"<")==0){
		if(z->kind==FUNCTION_OP){
			fprintf(obj_fp,"\tblt %s, %s, ",my_regs[x_num].name,my_regs[y_num].name);
			obj_print_function(z);
			fprintf(obj_fp,"\n");
		}
		else if(z->kind==LABEL_OP)
			fprintf(obj_fp,"\tblt %s, %s, label%d\n",my_regs[x_num].name,my_regs[y_num].name,z->op_u.var_no);
	}
	else if(strcmp(relop,">=")==0){
		if(z->kind==FUNCTION_OP){
			fprintf(obj_fp,"\tbge %s, %s, ",my_regs[x_num].name,my_regs[y_num].name);
			obj_print_function(z);
			fprintf(obj_fp,"\n");
		}
		else if(z->kind==LABEL_OP)
			fprintf(obj_fp,"\tbge %s, %s, label%d\n",my_regs[x_num].name,my_regs[y_num].name,z->op_u.var_no);
	}
	else if(strcmp(relop,"<=")==0){
		if(z->kind==FUNCTION_OP){
			fprintf(obj_fp,"\tble %s, %s, ",my_regs[x_num].name,my_regs[y_num].name);
			obj_print_function(z);
			fprintf(obj_fp,"\n");
		}
		else if(z->kind==LABEL_OP)
			fprintf(obj_fp,"\tble %s, %s, label%d\n",my_regs[x_num].name,my_regs[y_num].name,z->op_u.var_no);
	}
}

void obj_read(InterCodes p){
	save_regs();
	fprintf(obj_fp,"\taddi $sp, $sp, -4\n");
    fprintf(obj_fp,"\tsw $ra, 0($sp)\n");
    fprintf(obj_fp,"\tjal read\n");
    fprintf(obj_fp,"\tlw $ra, 0($sp)\n");
    fprintf(obj_fp,"\taddi $sp, $sp, 4\n");
    int reg_num=getReg(p->code->u.one.op);
    fprintf(obj_fp,"\tmove %s, $v0\n",my_regs[reg_num].name);
}
void obj_write(InterCodes p){
	save_regs();
	int reg_num=getReg(p->code->u.one.op);
	fprintf(obj_fp,"\tmove $a0, %s\n",my_regs[reg_num].name);
    fprintf(obj_fp,"\taddi $sp, $sp, -4\n");
    fprintf(obj_fp,"\tsw $ra, 0($sp)\n");
    fprintf(obj_fp,"\tjal write\n");
    fprintf(obj_fp,"\tlw $ra, 0($sp)\n");
    fprintf(obj_fp,"\taddi $sp, $sp, 4\n");
}

void obj_getaddr(InterCodes p){
	//find a reg i,and where p's op is in(temp->offset)
	//x := &y
	Operand x=p->code->u.two.op1;
	Operand y=p->code->u.two.op2;
	int x_num=getReg(x);
	OBJ_symList cur;
	for(cur=obj_list;cur!=NULL;cur=cur->next)
		if(compare_operand(y,cur->op)==0)break;
	if(cur==NULL){
		int reg=getReg(y);
		my_regs[reg].content->offset=-cur_offset;
		fprintf(obj_fp,"\taddi $sp, $fp, -%d\n",cur_offset);
		cur_offset=cur_offset+4;
	}
	else if(cur->offset>0){//not in stack,get a place in stack
		cur->offset=-cur_offset;
		fprintf(obj_fp,"\taddi $sp, $fp, -%d\n",cur_offset);
		cur_offset=cur_offset+4;
		fprintf(obj_fp,"\tsw %s, %d($fp)\n",my_regs[cur->reg].name,cur->offset);
	}
	fprintf(obj_fp,"\taddi %s, $fp, %d\n",my_regs[x_num].name,cur->offset);
}
void obj_function(InterCodes p){
	clear_regs();
	obj_list=NULL;cur_offset=4;
	fprintf(obj_fp,"\n");
	obj_print_function(p->code->u.one.op);
	fprintf(obj_fp,":\n");

	fprintf(obj_fp,"\taddi $sp, $sp, -4\n");
    fprintf(obj_fp,"\tsw $ra, 0($sp)\n");
    fprintf(obj_fp,"\taddi $sp, $sp, -4\n");
    fprintf(obj_fp,"\tsw $fp, 0($sp)\n");
    fprintf(obj_fp,"\tmove $fp, $sp\n");
	int off=8;
	for(InterCodes cur=p->next;cur->code->kind==PARAM_IR;cur=cur->next){
		int reg=getReg(cur->code->u.one.op);
		fprintf(obj_fp,"\tlw %s, %d($fp)\n",my_regs[reg].name,off);
		off=off+4;
	}
}
void obj_return(InterCodes p){
	int reg=getReg(p->code->u.one.op);
	fprintf(obj_fp,"\tmove $v0, %s\n",my_regs[reg].name);
    fprintf(obj_fp,"\taddi $sp, $fp, 4\n");
    fprintf(obj_fp,"\tlw $fp, 0($fp)\n");
	fprintf(obj_fp,"\tlw $ra, 0($sp)\n");
    fprintf(obj_fp,"\taddi $sp, $sp, 4\n");
    fprintf(obj_fp,"\tjr $ra\n");
}
void obj_dec(InterCodes p){
	//DEC x [size]
	Operand x=p->code->u.dec.x;
	int size=p->code->u.dec.size;
	OBJ_symList obj=(OBJ_symList)malloc(sizeof(struct OBJ_symList_));
	obj->next=obj_list;
	cur_offset+=size;
	obj->offset=-(cur_offset-4);
	obj->op=x;
	obj_list=obj;
	obj->reg=-1;
	fprintf(obj_fp,"\taddi $sp, $fp, %d\n",obj->offset);
}
InterCodes obj_arg(InterCodes p){
	save_regs();
	for(;p->code->kind==ARG_IR;p=p->next){
    	int reg=getReg(p->code->u.one.op);
		fprintf(obj_fp,"\taddi $sp, $fp, -%d\n",cur_offset);
		my_regs[reg].content->offset=-cur_offset;
		cur_offset=cur_offset+4;
    	fprintf(obj_fp,"\tsw %s, 0($sp)\n",my_regs[reg].name);
	}
	//op1 := CALL op2
	Operand op1=p->code->u.two.op1;
	Operand op2=p->code->u.two.op2;
	fprintf(obj_fp,"\tjal ");
	obj_print_function(op2);
	fprintf(obj_fp,"\n");
	int reg1=getReg(op1);
	fprintf(obj_fp,"\tmove %s, $v0\n",my_regs[reg1].name);
	return p;
}
void obj_call(InterCodes p){
	save_regs();
	//op1 := CALL op2
	Operand op1=p->code->u.two.op1;
	Operand op2=p->code->u.two.op2;
	fprintf(obj_fp,"\tjal ");
	clear_regs();
	obj_print_function(op2);
	fprintf(obj_fp,"\n");
	int reg1=getReg(op1);
	//fprintf(obj_fp,"\tli %s, %d\n",my_regs[reg1].name,cur_offset);
	fprintf(obj_fp,"\tmove %s, $v0\n",my_regs[reg1].name);
}
