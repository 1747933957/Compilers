#include "IR_structure.h"
InterCodes inter_code_head;
InterCodes inter_code_tail;

int v_count,label_count;
int inter_code_count;
VarList var_list_head;
LabelList label_list_head;

void InsertCode(InterCode c){
    InterCodes p=(InterCodes)malloc(sizeof(struct InterCodes_));
    p->code=c;
    p->next=NULL;
    if(inter_code_head==NULL){
        inter_code_head=p;
        inter_code_tail=p;
        p->prev=NULL;
    }
    else{
        inter_code_tail->next=p;
        p->prev=inter_code_tail;
        inter_code_tail=p;
    }
}
void print_operand(Operand op,FILE*fp){
    if(op->addr==STAR_OP)fprintf(fp,"*");
    else if(op->addr==AND_OP)fprintf(fp,"&");
    if(op->kind==VARIABLE_OP)fprintf(fp,"v%d",op->op_u.var_no);
    else if(op->kind==CONSTANT_OP)fprintf(fp,"#%d",op->op_u.value);
    else if(op->kind==FUNCTION_OP)fprintf(fp,"%s",op->op_u.name);
    else if(op->kind==LABEL_OP)fprintf(fp,"label%d",op->op_u.var_no);
}

void print_IR(FILE*fp){
    for(InterCodes c=inter_code_head;c!=NULL;c=c->next){
        InterCode p=c->code;
        if(p->kind==LABEL_IR){//LABEL x :
            fprintf(fp,"LABEL label%d :\n",p->u.one.op->op_u.var_no);
        }
        else if(p->kind==FUNCTION_IR){//FUNCTION f :
            fprintf(fp,"FUNCTION %s :\n",p->u.one.op->op_u.name);
        }
        else if(p->kind==ASSIGN_IR){//op1 := op2
            print_operand(p->u.two.op1,fp);
            fprintf(fp," := ");
            print_operand(p->u.two.op2,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==ADD_IR){//res := op1 + op2
            print_operand(p->u.three.res,fp);
            fprintf(fp," := ");
            print_operand(p->u.three.op1,fp);
            fprintf(fp," + ");
            print_operand(p->u.three.op2,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==SUB_IR){//x := y - z
            print_operand(p->u.three.res,fp);
            fprintf(fp," := ");
            print_operand(p->u.three.op1,fp);
            fprintf(fp," - ");
            print_operand(p->u.three.op2,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==MUL_IR){//x := y * z
            print_operand(p->u.three.res,fp);
            fprintf(fp," := ");
            print_operand(p->u.three.op1,fp);
            fprintf(fp," * ");
            print_operand(p->u.three.op2,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==DIV_IR){//x := y / z
            print_operand(p->u.three.res,fp);
            fprintf(fp," := ");
            print_operand(p->u.three.op1,fp);
            fprintf(fp," / ");
            print_operand(p->u.three.op2,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==GOTO_IR){//GOTO x
            fprintf(fp,"GOTO ");
            print_operand(p->u.one.op,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==IFGOTO_IR){//IF op1 [relop] op2 GOTO op3
            fprintf(fp,"IF ");
            print_operand(p->u.four.op1,fp);
            fprintf(fp," %s ",p->u.four.relop);
            print_operand(p->u.four.op2,fp);
            fprintf(fp," GOTO ");
            print_operand(p->u.four.op3,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==RETURN_IR){//RETURN x
            fprintf(fp,"RETURN ");
            print_operand(p->u.one.op,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==DEC_IR){//DEC x [size]
            fprintf(fp,"DEC ");
            print_operand(p->u.dec.x,fp);
            fprintf(fp," %d\n",p->u.dec.size);
        }
        else if(p->kind==ARG_IR){//ARG x
            fprintf(fp,"ARG ");
            print_operand(p->u.one.op,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==CALL_IR){//op1 := CALL op2,if(op1==NULL)call op2
            print_operand(p->u.two.op1,fp);
                fprintf(fp," := ");
            fprintf(fp,"CALL ");
            print_operand(p->u.two.op2,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==PARAM_IR){//PARAM x
            fprintf(fp,"PARAM ");
            print_operand(p->u.one.op,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==READ_IR){//READ x
            fprintf(fp,"READ ");
            print_operand(p->u.one.op,fp);
            fprintf(fp,"\n");
        }
        else if(p->kind==WRITE_IR){//WRITE x
            fprintf(fp,"WRITE ");
            print_operand(p->u.one.op,fp);
            fprintf(fp,"\n");
        }
    }
}

Operand copy_operand(Operand x){
    Operand y=(Operand)malloc(sizeof(struct Operand_));
    y->kind=x->kind;
    y->op_u=x->op_u;
    y->addr=x->addr;
    return y;
}

int compare_operand(Operand a,Operand b,int note_addr){
    //return 0-equal
    //note_addr=0:don't care addr,=1:care addr
    if(a->kind!=b->kind)return 1;
    else if(note_addr==1&&a->addr!=b->addr)return 1;
    if(a->kind==CONSTANT_OP)
        if(a->op_u.value==b->op_u.value)return 0;
        else return 1;
    else if(a->kind==FUNCTION_OP)
        if(strcmp(a->op_u.name,b->op_u.name)==0)return 0;
        else return 1;
    else{
        if(a->op_u.var_no==b->op_u.var_no)return 0;
        else return 1;
    }
}

InterCodes copy_intercodes(InterCodes x){
    InterCodes res=(InterCodes)malloc(sizeof(struct InterCodes_));
    res->num=x->num;
    res->prev=NULL;res->next=NULL;
    res->code=(InterCode)malloc(sizeof(struct InterCode_));
    res->code->kind=x->code->kind;
    res->code->u.three.op1=copy_operand(x->code->u.three.op1);
    res->code->u.three.op2=copy_operand(x->code->u.three.op2);
    res->code->u.three.res=copy_operand(x->code->u.three.res);
    return res;
}

int get_var_num(char*name){
    VarList p=NULL;
    for(p=var_list_head;p!=NULL;p=p->next)
        if(strcmp(p->name,name)==0)return p->var_num;
    p=(VarList)malloc(sizeof(struct VarList_));
    strcpy(p->name,name);
    p->next=var_list_head;var_list_head=p;
    ++v_count;p->var_num=v_count;
    return v_count;
}

int get_label_num(char*name){
    LabelList p=NULL;
    for(p=label_list_head;p!=NULL;p=p->next)
        if(strcmp(p->name,name)==0)return p->label_num;
    p=(LabelList)malloc(sizeof(struct LabelList_));
    strcpy(p->name,name);
    p->next=label_list_head;label_list_head=p;
    ++label_count;p->label_num=label_count;
    return label_count;
}