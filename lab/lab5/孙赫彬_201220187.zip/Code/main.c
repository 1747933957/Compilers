#include <stdio.h>
#include "IR_handle.h"
extern FILE* yyin;
extern int yylex();
extern int yylineno;
extern void yyrestart(FILE *input_file);
extern int yyparse (void);

int main(int argc, char** argv)
{
    v_count=label_count=0;inter_code_count=0;
    var_list_head=NULL;label_list_head=NULL;inter_code_head=NULL;
    if (argc <= 1) return 1;
    FILE* f = fopen(argv[1], "r");
    if (!f)
    {
        perror(argv[1]);
        return 1;
    }
    FILE *f2=fopen(argv[2],"wt+");
    //FILE *f2=fopen(argv[2],"a+");
    if(!f2){
        perror(argv[2]);
        return 1;
    }
    yyrestart(f);
    yyparse();
    IR_begin_handle();
    print_IR(f2);
    fclose(f);
    fclose(f2);
    return 0;
}
