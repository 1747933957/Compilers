#ifndef MY_OBJ
#define MY_OBJ
#include "InterTranslate.h"

typedef struct OBJ_symList_* OBJ_symList;
struct OBJ_symList_{
    Operand op;
    int offset;//=-1,if not in stack
    int reg;//=-1,not in reg
    OBJ_symList next;
};
OBJ_symList obj_list;
int cur_offset;

struct Reg
{
    char* name;
    int free;//0-free,1-not free
    OBJ_symList content;
    int pre_used_line;
    int can_free;//1-can be free
}my_regs[32];


void object_code_translate(FILE*fp);
void save_regs();
int getReg(Operand op);
void obj_label(InterCodes p);
void obj_function(InterCodes p);
void obj_assign(InterCodes p);
void obj_add(InterCodes p);
void obj_sub(InterCodes p);
void obj_mul(InterCodes p);
void obj_div(InterCodes p);
void obj_getaddr(InterCodes p);
void obj_getvalue(InterCodes p);
void obj_putaddr(InterCodes p);
void obj_goto(InterCodes p);
void obj_ifgoto(InterCodes p);
void obj_return(InterCodes p);
void obj_dec(InterCodes p);
InterCodes obj_arg(InterCodes p);
void obj_call(InterCodes p);
void obj_read(InterCodes p);
void obj_write(InterCodes p);
void clear_regs();
#endif