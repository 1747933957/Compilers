//
// Created by hby on 22-12-2.
//

#ifndef CODE_IR_OPTIMIZE_H
#define CODE_IR_OPTIMIZE_H

extern void IR_optimize();

#endif //CODE_IR_OPTIMIZE_H
