#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef DEF_STRUCTURE
#define DEF_STRUCTURE
//单条中间代码的数据结构定义为：
typedef struct Operand_* Operand;
struct Operand_ {
    enum { 
        VARIABLE_OP, //var_no
        CONSTANT_OP, //value
        FUNCTION_OP,//u.name
        LABEL_OP } kind;
    enum {
        NORMAL_OP,//v
        STAR_OP,//*v
        AND_OP//&v
    } addr;
    union {
        int var_no;
        int value;
        char name[32];
    } op_u;
};
typedef struct InterCode_* InterCode;
struct InterCode_
{
    enum {
        LABEL_IR,//LABEL x :
        FUNCTION_IR,//FUNCTION f :
        ASSIGN_IR,//op1 := op2
        ADD_IR,//res := op1 + op2
        SUB_IR,//x := y - z
        MUL_IR,//x := y * z
        DIV_IR,//x := y / z
        GOTO_IR,//GOTO x
        IFGOTO_IR,//IF op1 [relop] op2 GOTO op3
        RETURN_IR,//RETURN x
        DEC_IR,//DEC x [size]
        ARG_IR,//ARG x
        CALL_IR,//op1 := CALL op2
		PARAM_IR,//PARAM x
		READ_IR,//READ x
		WRITE_IR//WRITE x
    } kind;
    union {
        struct { Operand op; } one;
        struct { Operand op1, op2; } two;
        struct { Operand res, op1, op2; } three;
        struct { Operand op1, op2, op3; char relop[32]; } four;
        struct { Operand x; int size; } dec;
    } u;
};

//双向链表 实现可以写成：
typedef struct InterCodes_* InterCodes;
struct InterCodes_ { InterCode code; InterCodes prev, next; int num;};
extern InterCodes inter_code_head;
extern int v_count;
extern int label_count;
extern int inter_code_count;

typedef struct VarList_* VarList;
struct VarList_{char name[32];int var_num;VarList next;};
extern VarList var_list_head;

typedef struct LabelList_* LabelList;
struct LabelList_{char name[32];int label_num;LabelList next;};
extern LabelList label_list_head;

typedef struct OperandList_* OperandList;
struct OperandList_{Operand op;OperandList next;};

void InsertCode(InterCode c);
void print_operand(Operand op,FILE*fp);
void print_IR(FILE*fp);
Operand copy_operand(Operand x);
int compare_operand(Operand a,Operand b,int note_addr);//0-equal
InterCodes copy_intercodes(InterCodes x);
int get_var_num(char*name);
int get_label_num(char*name);
#endif